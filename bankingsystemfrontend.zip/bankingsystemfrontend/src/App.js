/* eslint-disable react-hooks/rules-of-hooks */
import logo from './logo.svg';
import './App.css';
import NavBar from './components/NavBar';
import Home from './pages/home';
import Footer from './components/Footer';
import {
  BrowserRouter as Router,
  Route,
  Routes,
} from "react-router-dom";
import Navbar from './components/NavBar';
import Login from './pages/Login';
import SignUp from './pages/SignUp';

import ProfilePage from './pages/ProfilePage';


// const [stompClient, setStompClient] = useState();
// const [isConnect, setIsConnect] = useState(false);

// const connect = ()=>{
//   const sock = new SockJS("http://localhost:9090/ws");
//   const temp = over(sock);
//   setStompClient(temp);

//   const headers = {
//     // Authotization: 'Bearer '
//     "X-XSRF-TOKEN": getCookies("XSRF-TOKEN")
//   }
// }

// function getCookies(name) {
//   const value = `; ${document.cookie}`;
//   const parts = value.split(`; ${name}=`)
//   if(parts.length===2) {
//     return parts.pop().split(";").shift();
//   }
// }
// const onError= (error)=> {
//   console.log(error)
// }
// const onConnect = ()=> {
//   setIsConnect(true)
// }

function App() {
  
  return (
    <>
    <Router>
          <NavBar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/signup" element={<SignUp />} />
          </Routes>
          <Footer />
      </Router>
    </>
  );
}

export default App;
