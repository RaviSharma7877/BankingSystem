/* eslint-disable jsx-a11y/anchor-is-valid */
import React from 'react'
import logo1 from '../assets/logo1.svg'
import logo from '../assets/logo.svg'

const Footer = () => {
  return (
    <footer>
        <div>
            <div>
                <div class="logo">
                    <a href="#">
                        <img src={logo1} alt="" />
                        <img src={logo} alt="" />
                    </a>
                </div>
                
            </div>
            <div>
                <div><p>About</p>
                    <ul>
                        <li>Products</li>
                        <li>Use cases</li>
                        <li>Company</li>
                        <li>Investors</li>
                        <li>Blog</li>
                    </ul>
                </div>
                <div><p>Platform</p>
                    <ul>
                        <li>Developers</li>
                        <li>Log in</li>
                        <li>Status</li>
                        <li>Say Hi</li>
                    </ul>
                </div>
                <div><p>Legal</p>
                    <ul>
                        <li>Privacy policy</li>
                        <li>Terms os Use</li>
                        <li>Cookies Policy</li>
                        <li>Merchant Terms & Conditions</li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
  )
}

export default Footer