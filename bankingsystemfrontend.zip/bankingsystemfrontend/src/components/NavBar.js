import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import logo1 from '../assets/logo1.svg'; // Import your logo images
import logo from '../assets/logo.svg';



function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const jwtToken = localStorage.getItem('jwtToken');


  let handelLogOut = ()=>{
    localStorage.removeItem("jwtToken");
                    console.log("Token removed");
                    navigate("/")
  }
  

  return (
    <header className="bg-white w-full fixed top-0 z-50">
      <nav className="flex justify-between items-center px-4 lg:px-20 py-2">
        <div className="logo flex">
          <Link to="/" className='flex justify-between items-center'>
            <img src={logo1} alt="" className="w-8 h-8 md:w-10 md:h-10" />
            <img src={logo} alt="" className="w-100 h-100 px-4 md:w-100 md:h-100" />
          </Link>
        </div>
        <div className="loginOrprofile">

        {jwtToken ? (
            
            location.pathname === '/profile' ? (
              <Link to="#">
                <button onClick={handelLogOut} className="loginOrprofilebtn px-4 py-2 rounded-full bg-black text-white text-sm md:text-base">Sign Out</button>
              </Link>
            ) : (
              <Link to="/profile">
              <button className="loginOrprofilebtn px-4 py-2 rounded-full bg-black text-white text-sm md:text-base">Profile</button>
            </Link>
            )
          ) : (

            location.pathname === '/login' ? (
            <Link to="/signup">
              <button className="loginOrprofilebtn px-4 py-2 rounded-full bg-black text-white text-sm md:text-base">Sign Up</button>
            </Link>
          ) : (
            <Link to="/login">
              <button className="loginOrprofilebtn px-4 py-2 rounded-full bg-black text-white text-sm md:text-base">Log in</button>
            </Link>
          )
          )}

          
        </div>
      </nav>
    </header>
  );
}

export default Navbar;
