/* eslint-disable no-unused-vars */
/* eslint-disable jsx-a11y/img-redundant-alt */
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleLogin = () => {
        var myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");
    
        // Set up the Authorization header for Basic Auth
        var authHeader = 'Basic ' + btoa(email + ':' + password);
        myHeaders.append("Authorization", authHeader);
    
        // Set up the fetch options without including the email and password in the body
        var requestOptions = {
            method: "POST",
            headers: myHeaders,
            redirect: "follow",
            // No need to include the email and password in the body
        };
    console.log(authHeader)
        // Send the POST request to the /signIn endpoint
        fetch('http://localhost:8080/api/signIn', requestOptions)
            .then((response) => {
                console.log(response)
                if (response.ok) {
                    var token = response.headers.get("Authorization");
                    localStorage.setItem("jwtToken", token);
                    console.log("Token stored:", token);
    
                    // Navigate to the home page after successful login
                    navigate("/");
                } else {
                    console.log("Error:", response.status);
                }
                return response.json();
            })
            .then((result) => {
                var token = result.token;
                console.log(result)
                setTimeout(() => {
                    localStorage.removeItem("jwtToken");
                    console.log("Token removed");
                }, 30000000);
            })
            .catch((error) => 
            {
                alert("something went wrong")
            console.log("error", error)
            });
    };

    return (
        <div className="container mx-auto p-3 my-5 logincontainer">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="col-span-1 md:col-span-1">
                    <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg" className="img-fluid" alt="Phone image" />
                </div>
                <div className="col-span-1 md:col-span-1">
                    <input
                        className="mb-4 mx-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        type="email"
                        placeholder="Email address"
                        value={email}
                        onChange={e => setEmail(e.target.value)}
                    />
                    <input
                        className="mb-4 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                    />
                    <div className="flex justify-between items-center mx-4 mb-4">
                        <div>
                            <input className="mr-2" type="checkbox" id="flexCheckDefault" />
                            <label htmlFor="flexCheckDefault">Remember me</label>
                        </div>
                        <a href="!#" className="text-blue-500">Forgot password?</a>
                    </div>
                    <button
                        className="mb-4 px-4 py-2 bg-blue-500 text-white rounded-lg w-full"
                        onClick={handleLogin}
                    >
                        Sign in
                    </button>
                    <div className="flex items-center my-4">
                        <div className="flex-grow border-t border-gray-300"></div>
                        <p className="mx-3 font-bold text-center">OR</p>
                        <div className="flex-grow border-t border-gray-300"></div>
                    </div>
                    <button className="mb-4 px-4 py-2 bg-blue-800 text-white rounded-lg w-full flex items-center justify-center">
                        <span className="mr-2">
                            <i className="fab fa-facebook-f"></i>
                        </span>
                        Continue with Facebook
                    </button>
                    <button className="mb-4 px-4 py-2 bg-blue-400 text-white rounded-lg w-full flex items-center justify-center">
                        <span className="mr-2">
                            <i className="fab fa-twitter"></i>
                        </span>
                        Continue with Twitter
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Login;
