/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from 'react';

const ProfilePage = () => {
  const [user, setUser] = useState(null);
  const [showLoanForm, setShowLoanForm] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [showBankForm, setShowBankForm] = useState(false);
  const [showTransferForm, setShowTransferForm] = useState(false);
  const [balanceAmount, setBalanceAmount] = useState('');
  const [accountType, setAccountType] = useState('');
  const [loanAmount, setLoanAmount] = useState('');
  const [paymentAmount, setPaymentAmount] = useState('');
  const [transferAmount, setTransferAmount] = useState('');
  const [recipientAccount, setRecipientAccount] = useState('');
  const jwtToken = localStorage.getItem("jwtToken");
  const userId = localStorage.getItem("userId");

  if (!jwtToken) {
    // Handle the case where the JWT token is not available
    return <div>JWT token not available</div>;
  }

  useEffect(() => {
    var myHeaders = new Headers();
    myHeaders.append("Authorization", `Bearer ${jwtToken}`);

    var requestOptions = {
      method: "GET",
      headers: myHeaders,
      redirect: "follow",
    };

    fetch(`http://localhost:8080/api/user/profile/userId?userId=${userId}`, requestOptions)
      .then(response => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error("Failed to fetch user data");
        }
      })
      .then(data => {
        setUser(data);
        console.log(data);
        setTimeout(() => {
          localStorage.removeItem("jwtToken");
          console.log("Token removed");
        }, 30000000);
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
      });
  }, []);

  const handleLoanSubmit = async (e) => {
    e.preventDefault();

    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", `Bearer ${jwtToken}`);

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      redirect: 'follow'
    };

    try {
      const response = await fetch(`http://localhost:8080/api/loan/apply-loan?accountNumber=${user.account.accountNumber}&amount=${loanAmount}`, requestOptions);
      if (response.ok) {
        const data = await response.json();
        setUser(data);
      } else {
        throw new Error("Failed to apply for loan");
      }
    } catch (error) {
      console.error('Error applying for loan:', error);
    }

    setShowLoanForm(false);
  };

  const handlePaymentSubmit = async (e) => {
    e.preventDefault();
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", `Bearer ${jwtToken}`);

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      redirect: 'follow'
    };

    try {
      const response = await fetch(`http://localhost:8080/api/payee/add?accountNumber=${user.account.accountNumber}&amount=${paymentAmount}`, requestOptions);
      if (response.ok) {
        const data = await response.json();
        setUser(data);
      } else {
        throw new Error("Failed to apply for loan");
      }
    } catch (error) {
      console.error('Error applying for loan:', error);
    }

    setShowPaymentForm(false);
  };

  const handleTransferSubmit = async (e) => {
    e.preventDefault();
    // Send money transfer request to the server
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", `Bearer ${jwtToken}`);

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      redirect: 'follow'
    };

    try {
      const response = await fetch(`http://localhost:8080/api/loan/apply-loan?fromAccountNumber=${user.account.accountNumber}&toAccountNumber=${recipientAccount}`, requestOptions);
      if (response.ok) {
        const data = await response.json();
        setUser(data);
      } else {
        throw new Error("Failed to apply for loan");
      }
    } catch (error) {
      console.error('Error applying for loan:', error);
    }

    setShowTransferForm(false);
  };

  const handleCreateAccount = async (e) => {
    e.preventDefault();
    var myHeaders = new Headers();
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Authorization", `Bearer ${jwtToken}`);

    var obj = {
        "balance": balanceAmount,
        "type": accountType
    };
    console.log(obj)
    var requestOptions = {
        method: 'POST',
        headers: myHeaders,
        body: JSON.stringify(obj),
        redirect: 'follow'
    };

    try {
        const response = await fetch(`http://localhost:8080/api/accounts/create/userId?userId=${userId}`, requestOptions);
        if (response.ok) {
            const data = await response.json();
            setUser(data);
        } else {
            throw new Error("Failed to open account");
        }
    } catch (error) {
        console.error('Error opening the account:', error);
    }
    setShowBankForm(false);
};


  if (!user) {
    return <div>Loading...</div>;
  }

  return (
    <div className="profilepage max-w-md mx-auto p-4 bg-gray-100 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">Profile Information</h2>
      <p><strong>Name:</strong> {user.username}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <p><strong>Bank Account Number:</strong> {user.account ? user.account.accountNumber : 'No bank account found'}</p>
      <p><strong>Balance:</strong> {user.account ? user.account.balance : 'No bank account found'} Rs.</p>

      {user.account ? (
        <>
          <button
            className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => setShowLoanForm(true)}
          >
            Apply for Loan
          </button>
          {showLoanForm && (
            <form onSubmit={handleLoanSubmit} className="mt-4">
              <label className="block">Loan Amount:</label>
              <input
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                className="block w-full border border-gray-300 rounded px-3 py-2"
              />
              <button
                type="submit"
                className="mt-2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              >
                Apply
              </button>
            </form>
          )}

          <button
            className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => setShowPaymentForm(true)}
          >
            Pay Loan Installment
          </button>
          {showPaymentForm && (
            <form onSubmit={handlePaymentSubmit} className="mt-4">
              <label className="block">Amount:</label>
              <input
                type="number"
                value={paymentAmount}
                onChange={(e) => setPaymentAmount(e.target.value)}
                className="block w-full border border-gray-300 rounded px-3 py-2"
              />
              <button
                type="submit"
                className="mt-2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              >
                Pay
              </button>
            </form>
          )}

          <button
            className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => setShowTransferForm(true)}
          >
            Transfer Money
          </button>
          {showTransferForm && (
            <form onSubmit={handleTransferSubmit} className="mt-4">
              <label className="block">Amount:</label>
              <input
                type="number"
                value={transferAmount}
                onChange={(e) => setTransferAmount(e.target.value)}
                className="block w-full border border-gray-300 rounded px-3 py-2"
              />
              <label className="block mt-2">Recipient's Account Number:</label>
              <input
                type="text"
                value={recipientAccount}
                onChange={(e) => setRecipientAccount(e.target.value)}
                className="block w-full border border-gray-300 rounded px-3 py-2"
              />
              <button
                type="submit"
                className="mt-2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              >
                Transfer
              </button>
            </form>
          )}
        </>
      ) : (
        <div>
          <p>No bank account found.</p>
          <button
            className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => setShowBankForm(true)}
          >
            Create Bank Account
          </button>
          {showBankForm && (
            <form onSubmit={handleCreateAccount} className="mt-4">
              <label className="block">Amount:</label>
              <input
                type="number"
                value={balanceAmount}
                onChange={(e) => setBalanceAmount(e.target.value)}
                className="block w-full border border-gray-300 rounded px-3 py-2"
              />
              <label className="block mt-2">Account Type:</label>
  <select
    value={accountType}
    onChange={(e) => setAccountType(e.target.value)}
    className="block w-full border border-gray-300 rounded px-3 py-2"
  >
    <option value="Savings">Savings</option>
    <option value="Checking">Checking</option>
    <option value="Investment">Investment</option>
  </select>
 
              <button
                type="submit"
                className="mt-2 bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded"
              >
                Open Account
              </button>
            </form>
          )}
        </div>
      )}
    </div>
  );
};

export default ProfilePage;
