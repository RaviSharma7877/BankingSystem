/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { useState } from "react";
import heroimg from "../assets/heroimg.png";
import logo1 from "../assets/logo1.svg";

const Home = () => {
  const [activeFilter, setActiveFilter] = useState("contiant");
  return (
    <>
      <div className="hero_main">
        <div className="grid grid-cols-2 gap-4 md:gap-8 md:grid-cols-2 xl:grid-cols-2 mx-auto max-w-screen-xl mt-16 px-4 md:px-10 lg:px-20">
          <div>
            <h1 className="font-semibold text-3xl md:text-5xl">
              <span className="message text-6xl text-purple-600">
                Instant payments
              </span>
              <span className="block mt-4">with Open Banking</span>
            </h1>
            <p className="mt-6 text-gray-700">
              Lorem ipsum dolor sit amet, consectetur adipisicing elit.
              Excepturi voluptates eveniet facere, provident molestiae rerum
              dignissimos alias consequatur consectetur culpa! Saepe cupiditate
              tempore vitae, pariatur soluta placeat facere quam quibusdam?
            </p>
            <a
              href="#"
              className="inline-block mt-8 px-6 py-3 rounded-full bg-purple-600 text-white font-semibold hover:bg-purple-700"
            >
              Apply for Loan{" "}
              <i className="fa-solid fa-arrow-right-long ml-2"></i>
            </a>
          </div>
          <div className="flex items-center justify-center">
            <div className="w-4/5 md:w-full js-hero-img-wrapper">
              <img src={heroimg} alt="" className="w-full h-auto" />
            </div>
          </div>
        </div>
        <div className="companies mt-16 px-4 md:px-10 lg:px-20">
          <div>
            <h1 className="text-2xl font-semibold">Our banks</h1>
          </div>
          <div>{/* Add content for companies section here */}</div>
        </div>
      </div>
      <section id="filterSection">
        <div>
          <h1>Payment way</h1>
          <h1>with</h1>

          <div className="filtercontainer">
            <div className="filters">
              <div
                className={`filter ${
                  activeFilter === "contiant" ? "filteractive" : ""
                }`}
                onClick={() => setActiveFilter("contiant")}
              >
                <img src={logo1} alt="" />
                <h1 className="px-2">Contiant</h1>
              </div>
              <div
                className={`filter ${
                  activeFilter === "regular" ? "filteractive" : ""
                }`}
                onClick={() => setActiveFilter("regular")}
              >
                <h1>Regular</h1>
              </div>
            </div>
            <div className="filterdata">
              {activeFilter === "contiant" && (
                <>
                  <div class="contiant">
                    <img
                      src="https://assets-global.website-files.com/63ce8fdfb773bb355dff79ca/63e23b8bcc55b71653fa911b_customer-img.jpg"
                      alt=""
                    />
                    <h2>Balance</h2>
                  </div>
                  <div class="contiant">
                    <img
                      src="https://assets-global.website-files.com/63ce8fdfb773bb355dff79ca/64119f4a2431e6c0b682ef72_logo-tabs.svg"
                      alt=""
                    />
                    <h2>Contiant</h2>
                  </div>
                  <div class="contiant">
                    <img
                      src="https://assets-global.website-files.com/63ce8fdfb773bb355dff79ca/63dbc528e12d680d163d95fb_Primary-color-Check-Icon.svg"
                      alt=""
                    />
                    <h2>Merchant</h2>
                  </div>
                </>
              )}
              {activeFilter === "regular" && (
                <>
                  <div className="regular">
                    <i className="fa-regular fa-user"></i>
                    <p>Customer</p>
                  </div>
                  <div className="regular">
                    <i className="fa-solid fa-cart-shopping"></i>
                    <p>Merchant</p>
                  </div>
                  <div className="regular">
                    <i className="fa-solid fa-rotate-right"></i>
                    <p>Gateway</p>
                  </div>
                  <div className="regular">
                    <i className="fa-solid fa-building-columns"></i>
                    <p>Acquiring Bank</p>
                  </div>
                  <div className="regular">
                    <i className="fa-regular fa-folder"></i>
                    <p>Processor</p>
                  </div>
                  <div className="regular">
                    <i className="fa-solid fa-money-check"></i>
                    <p>Card schemes</p>
                  </div>
                  <div className="regular">
                    <i className="fa-solid fa-mobile-screen-button"></i>
                    <p>Customer Bank</p>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </section>
      

      <section id="evolution" className="py-10 px-4 md:px-10 lg:px-20">
                <div className="text-center">
                    <h1 className="text-5xl font-semibold mb-4">Payment evolution for</h1>
                    <h1 className="text-5xl font-semibold mb-12">every industry</h1>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div className="text-center">
                        <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto">
                        <div class="svgs">
                        <svg width="39" height="47" viewBox="0 0 39 47" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M18.9414 15.2917C17.6534 16.2099 16.0773 16.75 14.375 16.75C10.0258 16.75 6.50001 13.2242 6.50001 8.875C6.50001 4.52576 10.0258 1 14.375 1C17.1942 1 19.6674 2.48144 21.0587 4.70832M0.771484 45.7548C1.19485 45.539 1.53906 45.1948 1.75477 44.7715C2.00001 44.2902 2.00001 43.6601 2.00001 42.4V29.35C2.00001 28.0899 2.00001 27.4598 1.75477 26.9785C1.53906 26.5552 1.19485 26.211 0.771485 25.9952M2.00001 41.6961H7.87316C8.63892 41.6961 9.39999 41.7872 10.1423 41.9695L16.348 43.4775C17.6945 43.8055 19.0973 43.8374 20.4578 43.5732L27.3192 42.2383C29.1317 41.8852 30.7991 41.0173 32.1058 39.7461L36.9603 35.0239C38.3466 33.6776 38.3466 31.493 36.9603 30.1444C35.7121 28.9302 33.7356 28.7935 32.3236 29.8232L26.6659 33.9509C25.8556 34.5432 24.8697 34.8621 23.8557 34.8621H18.3924L21.8699 34.862C23.83 34.862 25.4177 33.3175 25.4177 31.4108V30.7206C25.4177 29.1374 24.31 27.7569 22.7317 27.3742L17.3643 26.0689C16.4909 25.8571 15.5963 25.75 14.6971 25.75C12.5263 25.75 8.59677 27.5473 8.59677 27.5473L2.00001 30.306M33.5 11.125C33.5 15.4742 29.9743 19 25.625 19C21.2758 19 17.75 15.4742 17.75 11.125C17.75 6.77576 21.2758 3.25 25.625 3.25C29.9743 3.25 33.5 6.77576 33.5 11.125Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>
                        </div>
                        <h2 className="text-xl font-semibold mt-4">Lending</h2>
                        <p className="text-gray-700">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officiis, fugiat!</p>
                    </div>
                    <div className="text-center">
                        <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto">
                        <div class="svgs">
                        <svg width="36" height="52" viewBox="0 0 36 52" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.1011 3C16.3636 1.76281 18.0928 1 20.0001 1C23.8661 1 27.0001 4.13401 27.0001 8C27.0001 9.90734 26.2373 11.6365 25 12.899M21.0001 14C21.0001 17.866 17.8661 21 14.0001 21C10.1341 21 7.00009 17.866 7.00009 14C7.00009 10.134 10.1341 7 14.0001 7C17.8661 7 21.0001 10.134 21.0001 14Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M7.48749 37.2857H14.3446M10.9161 33.8571V40.7143M15.1143 27H20.4321C24.9319 27 27.1819 27 28.9478 27.8527C30.5027 28.6035 31.7946 29.8064 32.6543 31.3039C33.6307 33.0046 33.791 35.2488 34.1116 39.7372L34.5333 45.642C34.7402 48.5373 32.4471 51 29.5444 51C28.06 51 26.6523 50.3407 25.7021 49.2003L25.0589 48.4286C24.4707 47.7227 24.1765 47.3697 23.8416 47.0845C23.1395 46.4866 22.2895 46.0885 21.3807 45.9319C20.9472 45.8571 20.4877 45.8571 19.5688 45.8571H15.9776C15.0587 45.8571 14.5992 45.8571 14.1657 45.9319C13.2569 46.0885 12.4069 46.4866 11.7048 47.0845C11.3699 47.3697 11.0758 47.7226 10.4875 48.4286L9.84435 49.2003C8.89407 50.3407 7.48637 51 6.00199 51C3.09933 51 0.806254 48.5373 1.01306 45.642L1.43483 39.7372C1.75543 35.2488 1.91573 33.0046 2.89212 31.3039C3.7518 29.8064 5.04368 28.6035 6.59856 27.8527C8.36456 27 10.6145 27 15.1143 27Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>
                        </div>
                        <h2 className="text-xl font-semibold mt-4">iGamin and Forex</h2>
                        <p className="text-gray-700">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officiis, fugiat!</p>
                    </div>
                    <div className="text-center">
                        <div className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto">
                        <div class="svgs">
                        <svg width="36" height="45" viewBox="0 0 36 45" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M4.18774 28.625L18.0005 43.5L31.8127 28.625L18.0002 31.8125L4.18774 28.625Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M1.00024 20.1253L18.0002 24.375L35.0002 20.125L18.0002 1L1.00024 20.1253Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>
                        </div>
                        <h2 className="text-xl font-semibold mt-4">On-Demand Economy</h2>
                        <p className="text-gray-700">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officiis, fugiat!</p>
                    </div>
                    <div className="text-center">
                        <div  className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto">
                        <div class="svgs ">
                        <svg width="36" height="38" viewBox="0 0 36 38" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3.67456 37H31.6746" stroke="#537C7A" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <path d="M18 28.5711L24.9125 11.0258L23.1844 6.01292L21.4563 1M19.023 28.3185L34.4717 11.8869C34.7587 11.5817 34.9021 11.4291 34.9593 11.2553C35.0097 11.1022 35.0134 10.9383 34.9698 10.7832C34.9205 10.6072 34.7839 10.4488 34.5108 10.1319L27.0552 1.48099C26.9028 1.30419 26.8266 1.21579 26.7332 1.15224C26.6505 1.09593 26.5581 1.05411 26.4604 1.02869C26.3501 1 26.2311 1 25.9931 1H10.0069C9.76888 1 9.64987 1 9.53959 1.02869C9.44188 1.05411 9.34954 1.09593 9.26679 1.15224C9.1734 1.21579 9.09721 1.30419 8.94483 1.48099L1.48919 10.1319C1.21609 10.4488 1.07954 10.6072 1.03016 10.7832C0.986636 10.9383 0.990288 11.1022 1.04067 11.2553C1.09785 11.4291 1.24133 11.5817 1.52829 11.8869L16.977 28.3185C17.3317 28.6957 17.509 28.8843 17.7174 28.9541C17.9005 29.0153 18.0995 29.0153 18.2826 28.9541C18.491 28.8843 18.6683 28.6957 19.023 28.3185Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>
                        </div>
                    
                    <h2 className="text-xl font-semibold mt-4">Wealth management</h2>
                    <p className="text-gray-700">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officiis, fugiat!</p>

                </div>
                <div className="text-center">
                <div  className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto">
                <div class="svgs">
                        <svg width="42" height="42" viewBox="0 0 42 42" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M19.0001 6H33.6001C35.8403 6 36.9604 6 37.8161 6.43597C38.5687 6.81947 39.1806 7.43139 39.5641 8.18404C40.0001 9.03969 40.0001 10.1598 40.0001 12.4V15C40.0001 16.8638 40.0001 17.7957 39.6956 18.5307C39.2896 19.5108 38.5109 20.2895 37.5308 20.6955C36.7957 21 35.8639 21 34.0001 21M23.0001 36H8.40009C6.15988 36 5.03978 36 4.18413 35.564C3.43148 35.1805 2.81956 34.5686 2.43607 33.816C2.00009 32.9603 2.00009 31.8402 2.00009 29.6V27C2.00009 25.1362 2.00009 24.2044 2.30457 23.4693C2.71055 22.4892 3.48925 21.7105 4.46936 21.3045C5.20444 21 6.13633 21 8.00009 21M17.6001 26H24.4001C24.9601 26 25.2402 26 25.4541 25.891C25.6422 25.7951 25.7952 25.6422 25.8911 25.454C26.0001 25.2401 26.0001 24.9601 26.0001 24.4V17.6C26.0001 17.0399 26.0001 16.7599 25.8911 16.546C25.7952 16.3578 25.6422 16.2049 25.4541 16.109C25.2402 16 24.9601 16 24.4001 16H17.6001C17.04 16 16.76 16 16.5461 16.109C16.3579 16.2049 16.205 16.3578 16.1091 16.546C16.0001 16.7599 16.0001 17.0399 16.0001 17.6V24.4C16.0001 24.9601 16.0001 25.2401 16.1091 25.454C16.205 25.6422 16.3579 25.7951 16.5461 25.891C16.76 26 17.04 26 17.6001 26ZM32.6001 41H39.4001C39.9601 41 40.2402 41 40.4541 40.891C40.6422 40.7951 40.7952 40.6422 40.8911 40.454C41.0001 40.2401 41.0001 39.9601 41.0001 39.4V32.6C41.0001 32.0399 41.0001 31.7599 40.8911 31.546C40.7952 31.3578 40.6422 31.2049 40.4541 31.109C40.2402 31 39.9601 31 39.4001 31H32.6001C32.04 31 31.76 31 31.5461 31.109C31.3579 31.2049 31.205 31.3578 31.1091 31.546C31.0001 31.7599 31.0001 32.0399 31.0001 32.6V39.4C31.0001 39.9601 31.0001 40.2401 31.1091 40.454C31.205 40.6422 31.3579 40.7951 31.5461 40.891C31.76 41 32.04 41 32.6001 41ZM2.60009 11H9.40009C9.96014 11 10.2402 11 10.4541 10.891C10.6422 10.7951 10.7952 10.6422 10.8911 10.454C11.0001 10.2401 11.0001 9.96005 11.0001 9.4V2.6C11.0001 2.03995 11.0001 1.75992 10.8911 1.54601C10.7952 1.35785 10.6422 1.20487 10.4541 1.10899C10.2402 1 9.96014 1 9.40009 1H2.60009C2.04004 1 1.76001 1 1.5461 1.10899C1.35794 1.20487 1.20496 1.35785 1.10909 1.54601C1.00009 1.75992 1.00009 2.03995 1.00009 2.6V9.4C1.00009 9.96005 1.00009 10.2401 1.10909 10.454C1.20496 10.6422 1.35794 10.7951 1.5461 10.891C1.76001 11 2.04004 11 2.60009 11Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>
                </div>
                    
                    <h2 className="text-xl font-semibold mt-4">PSPs and EMIs</h2>
                    <p className="text-gray-700">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officiis, fugiat!</p>

                </div>
                <div className="text-center">
                <div  className="w-20 h-20 bg-gray-200 rounded-full flex items-center justify-center mx-auto">
                <div class="svgs">
                        <svg width="42" height="41" viewBox="0 0 42 41" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M29.6979 11.8721C29.6979 14.1789 28.7815 16.3912 27.1504 18.0223C25.5193 19.6535 23.307 20.5698 21.0002 20.5698C18.6934 20.5698 16.4811 19.6535 14.85 18.0223C13.2188 16.3912 12.3025 14.1789 12.3025 11.8721M2.80724 10.5705L1.28514 28.8356C0.958156 32.7594 0.794664 34.7213 1.45793 36.2348C2.04068 37.5645 3.05036 38.6618 4.32709 39.353C5.78023 40.1397 7.74893 40.1397 11.6863 40.1397H30.314C34.2514 40.1397 36.2201 40.1397 37.6733 39.353C38.95 38.6618 39.9597 37.5645 40.5424 36.2348C41.2057 34.7213 41.0422 32.7594 40.7152 28.8356L39.1931 10.5705C38.9118 7.1944 38.7711 5.50635 38.0235 4.22871C37.3651 3.10363 36.3848 2.20159 35.2089 1.63895C33.8736 1 32.1797 1 28.7919 1L13.2084 1C9.82064 1 8.12675 0.999999 6.79143 1.63894C5.61556 2.20159 4.63523 3.10363 3.97688 4.22871C3.22925 5.50635 3.08858 7.19439 2.80724 10.5705Z" stroke="#537C7A" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                    </div>
                </div>
                    
                    <h2 className="text-xl font-semibold mt-4">eCommerce</h2>
                    <p className="text-gray-700">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officiis, fugiat!</p>
                </div>
                </div>
            </section>

            <section id="startBuilding">
        <div>
            <div>
                <div>
                    <div>
                        <div></div>
                    </div>
                
                </div>
                
            </div>
            <div class="startBuildingContent">
                <h1>Start building today</h1>
                <p>Get in touch to learn how our open banking solution can increase efficiency and speed for your business.</p>
                <button>Get in touch <i class="fa-solid fa-arrow-right-long"></i></button>
            </div>
        </div>
    </section>
    </>
  );
};

export default Home;
