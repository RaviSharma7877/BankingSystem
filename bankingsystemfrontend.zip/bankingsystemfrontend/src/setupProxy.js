const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'ws://localhost:8080', // Change this to your WebSocket server URL
      ws: true,
      changeOrigin: true,
    })
  );
};
